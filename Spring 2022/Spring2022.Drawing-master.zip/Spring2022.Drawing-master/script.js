document.body.innerHTML += "<canvas id='canv'></canvas>";
document.body.style.setProperty('margin', '0px');
document.body.style.setProperty('background', 'gray');
document.body.style.setProperty('overflow', 'hidden');
document.documentElement.style.setProperty('margin', '0px');
document.title = "Reset";


//Change favicon function code from https://stackoverflow.com/a/35960429/10047920
const changeFavicon = link => {
  let $favicon = document.querySelector('link[rel="icon"]')
  // If a <link rel="icon"> element already exists,
  // change its href to the given link.
  if ($favicon !== null) {
    $favicon.href = link
    // Otherwise, create a new element and append it to <head>.
  } else {
    $favicon = document.createElement("link")
    $favicon.rel = "icon"
    $favicon.href = link
    document.head.appendChild($favicon)
  }
}

changeFavicon("data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🎯</text></svg>")

setInterval(draw, 33);

function draw() {
  let canvas = document.querySelector("#canv");
  // let width = window.innerWidth;
  // let height = window.innerHeight;
  let width = 450
  let height = 450;
  canvas.style.width = width + "px";
  canvas.style.height = height + "px";
  canvas.width = width;
  canvas.height = height;

  customDraw(canvas.getContext("2d"))
}