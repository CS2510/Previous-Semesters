import chai from "chai";
const expect = chai.expect;
import SceneManager from "../engine/scene-manager.js"

describe("SceneManager", function(){
	describe("length", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("constructor", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("changeScene", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("currentScene", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("allComponents", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("allPrefabs", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("allScenes", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
});