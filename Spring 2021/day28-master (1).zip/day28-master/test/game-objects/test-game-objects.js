export {default as SimpleGameObject} from "./simple-game-object.js"
export {default as OneComponentGameObject} from "./one-component-game-object.js"