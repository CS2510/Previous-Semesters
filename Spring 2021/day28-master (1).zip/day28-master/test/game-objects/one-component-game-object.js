export default{
  name:"One Component",
  components:[
    {
      name:"CircleGeometryComponent"
    }
  ]
}