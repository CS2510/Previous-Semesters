import Geometry from "./collisions.js"
export default class Line{
  constructor(){
    
  }

}