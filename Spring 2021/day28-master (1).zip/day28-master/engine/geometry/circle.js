import Geometry from "./collisions.js"

export default class Circle{
  constructor(radius){
    this.radius = radius;
  }
}