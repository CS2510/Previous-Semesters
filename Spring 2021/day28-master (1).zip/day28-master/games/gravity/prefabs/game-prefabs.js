export {default as BallPrefab} from "./ball-prefab-rigid-body.js"
export {default as BallPongPrefab} from './ball-pong-prefab.js'