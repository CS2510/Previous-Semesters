export default {
  name: "Car",
  components: [
    { name: "DrawGeometryComponent", args: ["black"] },
    { name: "RectangleGeometryComponent", args: [1, 1] },
    { name: "MoveCarComponent" }
  ]
}