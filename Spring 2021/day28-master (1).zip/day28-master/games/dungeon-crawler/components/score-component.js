export default  class ScoreComponent extends Engine.Component{
    constructor(gameObject){
        super(gameObject);
        this.score = 0;
    }
}