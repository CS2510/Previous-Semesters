export {default as MainControllerComponent} from "./main-controller-component.js"
export {default as AsteroidComponent} from "./asteroid-update-component.js"
export {default as ShipUpdateComponent} from "./ship-update-component.js"