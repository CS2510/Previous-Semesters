export {default as AsteroidPrefab} from "./asteroid-prefab.js"
export {default as ShipPrefab} from "./ship-prefab.js"