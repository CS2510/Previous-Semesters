export default {
  name: "Car",
  components: [
    { name: "DrawGeometryComponent", args: ["black"] },
    { name: "RectangleGeometryComponent", args: [100, 75] },
    { name: "MoveCarComponent" }
  ]
}