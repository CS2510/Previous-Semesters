export default {
  name: "frog",
  components: [
    { name: "DrawGeometryComponent", args: ["green"] },
    { name: "RectangleGeometryComponent", args: [75, 75] },
    { name: "KeyboardBumpComponent", args: [100] }
  ]
}