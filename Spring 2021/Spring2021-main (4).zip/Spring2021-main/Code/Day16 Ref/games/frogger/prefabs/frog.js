export default {
  name: "frog",
  components: [
    { name: "DrawGeometryComponent", args: ["green"] },
    { name: "CircleGeometryComponent", args: [.5] },
    { name: "KeyboardBumpComponent", args: [1] }
  ]
}