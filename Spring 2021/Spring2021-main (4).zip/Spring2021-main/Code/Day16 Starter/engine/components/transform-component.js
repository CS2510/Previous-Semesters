import Component from "../component.js"

export default class TransformComponent extends Component {
 
}