class Component{
    constructor(gameObject){
        this.gameObject = gameObject;
    }
}

export default Component;