export default {
  name: "frog",
  components: [
    { name: "DrawGeometryComponent", args: ["green"] },
    { name: "CircleGeometryComponent", args: [32] },
    { name: "KeyboardBumpComponent", args: [100] }
  ]
}