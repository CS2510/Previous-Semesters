export default {
  name:"RedRectangle",
  children:[],
  components:[
    {
      name:"DrawComponent",
      args:["red"]
    },
    {
      name:"MoveComponent"
    }

  ]
}