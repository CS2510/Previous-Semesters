export default {
  name:"BlueRectangle",
  components:[
    {
      name: "MoveComponent"
    },
    {
      name: "DrawComponent",
      args:["blue"]
    }
  ]
}