export default {
  name:"RedRectangle",
  components:[
    {
      name: "MoveComponent"
    },
    {
      name: "DrawComponent",
      args:["red"]
    }
  ]
}