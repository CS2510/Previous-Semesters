export default {
  name:"ClickToDestroy",
  children:[],
  components:[
    {
      name:"DrawComponent",
      args:["green"]
    },
    {
      name:"ClickToDestroyComponent",
      args:[2]
    }

  ]
}