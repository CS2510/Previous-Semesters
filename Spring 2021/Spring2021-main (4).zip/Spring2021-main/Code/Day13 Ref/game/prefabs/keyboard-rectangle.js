export default {
  name:"KeyboardRectangle",
  children:[],
  components:[
    {
      name:"DrawComponent",
      args:["yellow"]
    },
    {
      name:"KeyboardMoveComponent",
      args:[2]
    }

  ]
}