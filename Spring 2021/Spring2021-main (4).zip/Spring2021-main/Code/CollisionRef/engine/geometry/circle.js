export default class Circle{
  constructor(x,y,r){
    this.x = x;
    this.y = y;
    this.radius = r;
  }
}