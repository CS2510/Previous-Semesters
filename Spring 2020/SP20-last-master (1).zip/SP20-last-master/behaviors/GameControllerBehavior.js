class GameControllerBehavior extends Behavior {
  constructor() {
    super();
    //Track time
    //Time between enemy instantiate
    //Time between death and next scene
    //Get reference to enemy prefab
    this.score = 0;
    //Possible states
    //current state

   
  }
  start() {

  }
  update(gameObject) {
    //Update time
    //Check state
    //Create enemies if needed
    //Switch scenes if needed
    
  }
  destroyMainCharacter(mainCharacter) {

    //Destroy game object
    //Create new particle system from scratch
    //Change game state
    
  }
}