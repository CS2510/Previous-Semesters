class BulletBehavior extends Behavior{
  constructor(){
    super();
    this.speed = 20;
  }
  start(){

  }
  update(gameObject){
    gameObject.transform.position.y += this.speed * Time.deltaTime;
  }
  onCollision(collider, gameObject, otherCollider, otherGameObject) {
   //Add particle system
   //Destroy game object
   //update score
  }
}