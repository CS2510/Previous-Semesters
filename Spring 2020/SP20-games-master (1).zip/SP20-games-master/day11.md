# Day 11 - Physics 1

## From the last sprint

- Your draw calls need to draw about the origin. If you object is at world space oX, oY, ctx.fillRect(0,0,1,1) and then ctx.translate(oX,oY), NOT ctx.fillRect(oX,oY,1,1)
- Stop bubbling with e.stopPropogation()

- How to get my game online. For Free. (And without someone else putting their ads on your site.)
    - Netlify will publish your github repo online for free.
    - Cloudflare
    - DNS (URL)
    - Ways to get a cheap URL:
    - Namecheap sells urls really cheap.
    - Github developer pack (free)...free URL from namecheap for free.

- I can help you with this.

## Review Collision Detection

![Trig](./Trig.png)

![Collision Grid](./CollisionGrid.png)

We want to do something when there is a collision. This leads us into physics.

Newton's three laws (abbreviated):

- Objects in motion stay in motion, objects in rest stay at rest (momentum)
- Force = Mass * Acceleration
- Every action has an equal and opposite reaction

(You can read a lot more about these online, I recommend the article on [Wikipedia](https://en.wikipedia.org/wiki/Newton%27s_laws_of_motion))

This third law can be referred to as conservation of momentum and is the one we are going to focus on today. When an moving object collides with a stationary object, we will have that moving object rebound off the stationary object in a way that conserves momentum. 

In the ideal case when no energy is lost in a collision we have an [elastic collision](https://en.wikipedia.org/wiki/Newton%27s_laws_of_motion). This means there is no heat, sound, etc. generated from the collision. These collisions don't exist outside of quantum physics, but they exist all over in video games (think pong). Our goal today is to calculate elastic collisions between points and arbitrarily rotated rectangles.

![Reflections](./Reflections.png)
