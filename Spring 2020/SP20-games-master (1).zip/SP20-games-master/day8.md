# Day 8 - Collision Dection I


## JS Scopes

- Global Scope
- Function Scope
- Class Scope

## Code Updates

[Starter Code](https://github.com/CS2510/code/blob/master/Day8Starter.zip)

### Component-based System

### Collisions

![Collision Difficulty](./CollisionDifficultySpectrum.png)

![Convex vs Concave](./ConvexVConcave.png)

![Collision Grid](./CollisionGrid.png)

