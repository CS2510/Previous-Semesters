# Day 15 - Instantiating, Destroying, and Particles


## Final Presentation

The instructions have a link on the front page. If you forget, the same link is right [here](https://github.com/bricksphd/teaching/blob/master/FinalPresentation.pdf).


[Starter Code](https://github.com/cs2510/last)

## Instantiating

## Destroying

## Particles

## In-scene State Machines

## A Look Back

## On to Unity