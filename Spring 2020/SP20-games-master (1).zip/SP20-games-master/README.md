# Intro to Game Programming

 ## Getting Ready For Class

 Online Resources
 - [Canvas](https://canvas.unomaha.edu) for grades
 - [Github](https://github.com/CS2510/code) for code
 - This website for notes
 - [Syllabus repo](https://github.com/bricksphd/teaching) for the syllabus

 ## Technologies

 - All our games will be written from scratch in [Javascript](https://w3schools.com/js).
 - Everything will be maintained on [Github](https://github.com). Get a free account if you don't already.
 

 ## Final Presentation

 - You can read about the requirements for the final presentation [here](https://github.com/bricksphd/teaching/blob/master/FinalPresentation.pdf).
 - You can read about the main topics of the course you should cover in your final [here](topics.md).
 
 General Final Presentation Rubric
 
 | Area                 | 
|----------------------|
| Course Topics        | 
| Presentation Quality | 
| Course Comprehension | 

 ## Course Calendar

 <iframe src="https://calendar.google.com/calendar/embed?src=9tflkh8l56ni973a0d60hhgu20%40group.calendar.google.com&ctz=America%2FChicago" style="border: 0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
