# Day 14 - Rendering Problems

## Extra Credit Reminder

## Starter Code

[Starter Code](https://github.com/CS2510/deferred/commit/a1a4995b589b1a13475cf9f2ae463a52a69f19a8)

- Better Prefabs

- Updating Text

## Rendering Problems
![RenderingProblems](./RenderingProblems.png)

## Double Buffering
![DoubleBuffering](./DoubleBuffering.png)

## Deferred Rendering
![DeferredRendering](./DeferredRendering.png)

## Ending Code

[Ending Code](https://github.com/CS2510/deferred)



