# Day 9 - Collision Detection II

## Game Motivations 

[Quantic Foundry](https://quanticfoundry.com/#iLightbox[b39ad34b5860b128436]/0)

## Points, Lines and Triangles

[Day 9 Starter](https://github.com/CS2510/code/blob/master/Day9Starter.zip)

![Lines](./Lines.png)

![Point Triangle Collisions](./PointTriangleCollisions.png)

