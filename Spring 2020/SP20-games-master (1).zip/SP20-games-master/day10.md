# Day 10 - Architecture and Picking

## The game engine architecture

- Scenes
- Game Objects (actors)
- Components (behaviors)

See [the presentation](./Arch.pptx) for more details

## Example code

You can see a single-file example of this three-tier architecture in a simple game here.

If you follow this architecture, you can also use a debugging html file to inspect the scenes, game objects, and components in your game. This doesn't require a change in your code.

## Picking

Picking is a the processing of taking user clicks and changing them from screen space coordinates into world space coordinates to see what the user clicked on. Doing this involves reversing the transformations done when rendering.
