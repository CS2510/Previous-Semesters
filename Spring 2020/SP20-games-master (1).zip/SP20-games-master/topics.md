# Main Topics

- Scene state machine
- Separation of concerns (MVC)
- Drawing to the screen
- UI layout and screen size independence (anchors)
- Model, World, Camera, Screen space 
- Scene hierarchy
- Screen, Camera, World, Model space (picking)
- User input 
- Event handling v polling
- 3-tiered architecture
- Collision detection
- Physics
- Gravity
- Rendering Improvements
