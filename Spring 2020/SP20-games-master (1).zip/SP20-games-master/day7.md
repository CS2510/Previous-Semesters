# Day 7 - Events v. Polling

## Coding

![EventsVsPolling.png](./EventsVsPolling.png)

The starting code is now in more than one file, so it lives in its own repo. You can see it on [GitHub here](https://github.com/CS2510/baseCode) or directly download a [zip of the files here](https://github.com/CS2510/baseCode/archive/master.zip)

The following things have changed since Day 6:

- The different scenes are now in their own files.
- There are a lot of comments.
- There is only one canvas that is shared between the scenes.
   - As a result, there is no longer any need for the html templates. This significantly reduces the boilerplate in the code.
- The main game content has been moved into the run state where it belongs.
- The game logic and game rendering in each scene have been appropriate split between an update() and render() method.


### Encapsulation

As our games become bigger, we need to start encapsulating our code. To do this, we will start using classes in JavaScript. The three classes we introduced today are the Vector2 class, the Transform class, and the GameObject class. By having all objects in a scene descend from the GameObject class, we can dramatically simplify the render method in our scene.

The result of today's code is a simple game where the user uses the WASD keys to move their blue square to remove "bad" red squares. You can find the final code [here](https://github.com/CS2510/code/blob/master/Day7End.zip).  A cleaner version of the code can be found [here](https://github.com/CS2510/code/blob/master/Day7Cleaned.zip).
