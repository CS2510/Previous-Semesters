# Unity Transition

## Key Topics

## Scene state machine

Unity opens with a new scene already open for you. In Unity 2018+ this scene has already been saved in the Assets/Scenes folder. By default you will scene the hierarchy window showing the GameObjects in the current scene. If you click on a GameObject you will see its collection of components in the Inspector window.

To transition between scene:
- Add a new scene to Unity
- Add that scene to the build path
  - Have the scene open in Unity
  - Go to File/Build Settings...
  - Click "Add Open Scene"
- In the MonoBehvaior Script where you want the Scene change to happen add the following code
  - using UnityEngine.SceneManagement; //At the top of the file
  - SceneManager.LoadSceneAsync("Scene2"); //Where you want the scene change to happen

## Separation of concerns (MVC)

Unity forces you to place you login in components in scripts that inherit from a class called MonoBehavior (similar to the Behavior class we used). By default they have a Start() and Update() method which perform the same thing that our code has. These functions have access to a local gameObject method that gives you access to the component's parent GameObject.


## Drawing to the screen

Similar to our code, if a GameObject has a component that a sprite (2D) or renderer (3D), then it will be drawn to the screen. 

GameObjects are given color by making a Material (a project level asset) and then attaching that Material as a component to a GameObject.

## UI layout and screen size independence (anchors)

Screen space-oriented GameObjects are placed in a special "Canvas" parent GameObject. They can be placed placed using anchors just like our code in class. They can stretch with the screen size or be anchor to a particular corner.

## Model, World, Camera, and Screen space (including picking) 

Understanding the difference between model, world, camera, and screen space is not always transparent in Unity. That is one of the reasons we spent so much time discussing it in class. 
- Each GameObject has a transform member variable (just like our code). Each Transform object has a position value (just like our code). This value holds the GameObject's position in world space *even if it is the child of another object.* If you want the position of a GameObject relative to its parent GameObject, each transform has a special getter localPosition that returns the GameObject's position relative to its parent.
- Unity does not have any built in methods for moving in and out of camera space.
- Unity has a built in method to move from world space to screen space, WorldToScreenPoint.
- Unity has a built in method for "pickingi" or moving from a screen point to world space, ScreenPointToRay. Note that since this is a projection from a 2D coordinate to a 3D space, this method returns a ray, not just a point.


## Architecture and Object Composition

Unity uses a three-tiered model in its system: scenes, game objects, and components. This systems relies on object compositions as opposed to polymorphism. This is a powerful approach that allows GameObjects to change at runtime, but requires a different train of thought when inspecting the type of objects. To find specific GameObjects in Unity, you have two main choices, names and tags.
- Each GameObject has a name that is a string. You can find GameObjects in a scene and prefabs in a project based on their name.
- Each GameObject also has a list of tags. You can find GameObjects in a scene in a project based on their tag.
- Each component on a GameObject has a type. You can find if a GameObject has a specific component or access the component itself using the GetComponent method


## Event handling v polling

As discussed in class, there are two major ways of handling user input -- events (did the user push the key?) and polling (is the user holding down the key?). Unity provides ways of handling both kinds of user input.

### Polling

```csharp
void Update()
{
  if(Input.GetKey("up")){
      //Polling event response. Called as long as the key is down
  }
}
```

### Event Handling

```csharp
void Update()
{    
  if(Input.GetKeyDown("space")){
      //Event handling. Called only when the key goes down.
  }
}
```


## Collision detection

Unity's collision detection system works by adding collider components to GameObjects. When an object has a collider component, any behaviors with the correct methods (e.g. OnCollissionEnter), will be called. Similar to our code, there are multiple types of collider components that can be attached to GameObjects in Unity. More complex colliders give better results but take longer to run.


## Physics

In order to use Unity's physics engine, you need to add a RidigBody component to a GameObject. When a GameObject has an attached RidigBody, it will respond to other objects that have collider components.

::: warning
 If you add a behavior to a GameObject with a RidigBody compoment, you need to use the FixedUpdate method instead of the Update method. The reasons are beyond the scope of this document, but if you do not, terrible things *will* happen.
:::


## Deferred Rendering

Unity allows you to do deferred rendered similar to what we did in class. In order to do this, create a new camera in a scene's hierarchy. In this camera's Camera component, change the ViewportRect settings to have this camera GameObject render to a specific section of the screen. This will allow for minimaps, split screen games, etc.