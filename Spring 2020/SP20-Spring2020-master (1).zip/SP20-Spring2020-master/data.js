export default [
  {
    name:"State Machines",
    sub: [
      {name: "Scene State Machines"},
      {name:"Animation State Machines"},
    ]
  },
  {
    name:"Drawing on a Canvas",
    sub:[
      {name:"Vectors v Pixels"},
      {name:"Game Looop"},
      {name:"Cameras"},
      {name:"UI Elements"},      
    ]
  },
  {
    name:"Three Pillars",
    sub: [
      {name: "Scenes"},
      {name: "Game Objects"},
      {name: "Components & Behaviors"}
    ]
  },
  {
    name:"Computational Geometry",
    sub:[
      {name:"Rectangle Representations"},
      {name:"Elipse Representations"},
      {name:"Line Representations"},
      {name:"Triangle Representations"},
      {name:"Convex v Concave"},
      {name:"Triangle Decomposition"},      
    ]
  },
  {
    name:"Linear Algebra Intro",
    sub:[
      {name:"Translate"},
      {name:"Scale"},
      {name:"Rotate"},
      {name:"Reversing Matrices"},
      {name:"Save and Restore"},
      {name:"Picking"}
    ]
  },
  {
    name:"Behaviors",
    sub: [
      {name: "Finding Other Components"},
      {name: "Finding Other Game Objects"},      
    ]
  },
  {
    name:"Input",
    sub:[
      {name:"Keyboard Input"},
      {name:"Moues Input"},
      {name:"Digital v. Analog Input"},
      {name:"Polling v Events"},

    ]
  },
  {
    name:"Collisions",
    sub:[
      {name:"Collision Difficulty"},
      {name:"Collision Hierarchies"},
      {name:"Points"},
      {name:"Circles"},
      {name:"Axis-Aligned Bounding Box"},
    ]
  },
  {
    name:"Physics",
    sub:[
      {name:"Linear v Rotational"},
      {name:"Axis Independence"},
      {name:"Acceleration, Velocity, & Position"},
    ]
  }
];
