# Next Steps

## Courses: 

- CSCI 3510 - Advanced Game Programming (Unity)
- CSCI 4620 - Computer Graphics (Rendering/GPU)

## Commerical Game Engines

- Unity
    - Designed for programmers (C#)
    - Designed first for mobile
- Unreal
    - Child of the commerical Unreal series (C++)
    - Beautiful/Fast

Trends
    - Unity is trying to get in the console/PC space
    - Unreal is trying to get in the mobile market
    - Both are trying to branch out into
        - Film, Mandalorean was rendered in realtime with Unreal
        - Architecture
        - etc. 
    
Other options

- All-in-one IDEs, like Unity and Unreal. Transpile.
- Headless engines.  Often open source. No IDE.
    - Ogre (C++)
    - JMonkey (Java)
- Render Engines (often tuned for game use)
    - THREE.js 
