import Behavior from "./Behavior.js"

class RectanlgeBehavior extends Behavior{
    /* Set the inital rotation to 0 */

    /* rotate slowly with time */
}

export default RectanlgeBehavior;