/* import statements */

/* Setup Scenes, game Objects, components, and behaviors */

let currentScene = startScene;

let canv, ctx;

function main() {
    canv = document.querySelector("#canv");
    ctx = canv.getContext('2d');

    /* setup game loop speed */
}

function gameLoop() {
    /* setup roles of game loop */
}

function update() {
    /* What does the update function do? */
}

function draw(ctx) {
    /* What does the draw function do? */
}

main();

