import Component from "./Component.js"

class Behavior extends Component{

    /* A Behavior is a component with a start and update function */

}

export default Behavior;