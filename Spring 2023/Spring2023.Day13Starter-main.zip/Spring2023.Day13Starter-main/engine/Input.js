class Input{
  static mouseX = 0;
  static mouseY = 0;
  static start(){
    let canvas = document.querySelector("#canv")
    //Update the values of mouseX and mouseY
  }
}

window.Input = Input;
export default Input;