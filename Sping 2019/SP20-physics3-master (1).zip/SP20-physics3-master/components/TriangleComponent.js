class TriangleComponent extends GeometryComponent{
  constructor(Triangle){
    super()
    this.Triangle = Triangle;
  }
}