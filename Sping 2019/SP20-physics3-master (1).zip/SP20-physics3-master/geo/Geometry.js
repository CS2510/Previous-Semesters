class Geometry{
  constructor(){
    
    
  }

}