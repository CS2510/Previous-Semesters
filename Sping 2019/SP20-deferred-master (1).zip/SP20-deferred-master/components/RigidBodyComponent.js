class RigidBodyComponent extends Component{
  constructor(){
    super();
    
  }
  update(gameObject){

    


  }
  get exposed (){return []  }
}