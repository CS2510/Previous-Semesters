
//The behavior script for our main character
var Time = {}                                     //Stores information about time that is available to our game
var msBetweenFrames = 1000 / 60;                //Time in milliseconds between frames
Time.deltaTime = msBetweenFrames / 1000;        //Time in seconds between frames.

//Setup the canvas variables
var canvas = document.getElementById("canv");
canvas.style.width = '100%';
canvas.style.height = '100%';
canvas.width = canvas.offsetWidth;
canvas.height = canvas.offsetHeight;

var width = canvas.width;
var height = canvas.height;


var ctx = canvas.getContext("2d");

class RotatorBehavior extends Behavior {
  constructor() {
    super("Rotator Behavior")
    this.speed = .5;
  }
  update(gameObject) {
    gameObject.transform.rotation += this.speed * Time.deltaTime;
  }
}


class BallBehavior extends Behavior {
  constructor(hierarchy) {
    super("Ball Behavior"); //Component name
    this.speed = 30;//Speed of the character
    this.direction = 1.5;
    this.hierarchy = hierarchy;
  }
  update(gameObject) {
    gameObject.transform.position.x += Math.cos(this.direction) * this.speed * Time.deltaTime;
    gameObject.transform.position.y += Math.sin(this.direction) * this.speed * Time.deltaTime;


  }
  onCollision(collider, gameObject, otherCollider, otherGameObject) {
    console.log("In a collision");

    //How to figure out the new direction of the ball?

    var x = Math.cos(this.direction);
    var y = Math.sin(this.direction);

    var rectangle = otherCollider.Geometry;

    if(rectangle.width > rectangle.height){
      y *= -1;
    }
    else{
      x *= -1;
    }



    this.direction = Math.atan2(y,x);

    var rand = Math.random() * 2 - 1
    rand *= .1;
    this.direction += rand;
    

  }
}


//The main scene in our game
class MyScene extends Scene {
  constructor() {
    super("Bounce Scene"); //The name of our scene
  }
  start() {
    this.camera = new Camera(20, "azure");// Add a camera game object
    this.camera.transform.position = new Vector2(1 / 2, 1 / 2); //Set its position


    //Push all our game objects into the scene
    this.hierarchy.push(this.camera);




    var wall = new GameObject("Wall");
    wall.transform.position = new Vector2(0, 10);
    var wallGeometry = new AxisAlignedRectangle(20, 1);
    wall.components.push(new GeometryComponent(wallGeometry));
    var wallRenderer = new GeometryRendererComponent("blue", wallGeometry);
    wall.components.push(wallRenderer);
    wall.renderer = wallRenderer;
    wall.components.push(new Collider(wallGeometry));
    this.hierarchy.push(wall);

    var wall = new GameObject("Wall2");
    wall.transform.position = new Vector2(0, -10);
    var wallGeometry = new AxisAlignedRectangle(20, 1);
    wall.components.push(new GeometryComponent(wallGeometry));
    var wallRenderer = new GeometryRendererComponent("blue", wallGeometry);
    wall.components.push(wallRenderer);
    wall.renderer = wallRenderer;
    wall.components.push(new Collider(wallGeometry));
    this.hierarchy.push(wall);

    var wall = new GameObject("Wall3");
    wall.transform.position = new Vector2(10, 0);
    var wallGeometry = new AxisAlignedRectangle(1, 20);
    wall.components.push(new GeometryComponent(wallGeometry));
    var wallRenderer = new GeometryRendererComponent("blue", wallGeometry);
    wall.components.push(wallRenderer);
    wall.renderer = wallRenderer;
    wall.components.push(new Collider(wallGeometry));
    this.hierarchy.push(wall);

    var wall = new GameObject("Wall4");
    wall.transform.position = new Vector2(-10, 0);
    var wallGeometry = new AxisAlignedRectangle(1, 20);
    wall.components.push(new GeometryComponent(wallGeometry));
    var wallRenderer = new GeometryRendererComponent("blue", wallGeometry);
    wall.components.push(wallRenderer);
    wall.renderer = wallRenderer;
    wall.components.push(new Collider(wallGeometry));
    this.hierarchy.push(wall);

    var wall = new GameObject("Rotating Wall");
    wall.transform.position = new Vector2(0, 2);
    wall.transform.rotation = 0;
    var wallGeometry = new AxisAlignedRectangle(6, 6);
    wall.components.push(new GeometryComponent(wallGeometry));
    var wallRenderer = new GeometryRendererComponent("black", wallGeometry);
    wall.components.push(wallRenderer);
    wall.renderer = wallRenderer;
    wall.components.push(new Collider(wallGeometry));
    //wall.components.push(new RotatorBehavior());
    this.hierarchy.push(wall);

    var ball = new GameObject("Ball");
    ball.transform.position = new Vector2(0, 0);
    var ballGeometry = new Vector2();
    ball.components.push(new GeometryComponent(ballGeometry));
    let renderer = new GeometryRendererComponent("red", ballGeometry);
    ball.components.push(renderer);
    ball.renderer = renderer;
    ball.components.push(new BallBehavior(this.hierarchy));
    ball.components.push(new Collider(ballGeometry));
    this.hierarchy.push(ball);



  }
}

var allScenes = [];

//Code to start the game
function main() {
  scene = new MyScene();//Instantiate the main scene
  scene.start(); //Start the main scene
  updateListeners.push(scene); //Have the scene listen to events
  allScenes.push(scene); //Let the debugger know about our scene
  setInterval(timer, msBetweenFrames);  //Start the main timer to be called 30 times a second (every 33.3ms)

  //Tell the debugger about us if we are in debugging mode
  if (typeof app != "undefined") {
    app.loadScenes();
    app.changeSceneEvent(scene);
  }
}
