function updateStateHandler(newState) {
  if (!newState) {
    if (state == TITLE_STATE) {
      stateHandler = titleStateHandler;
    } else if (state == LOAD_STATE) {
      stateHandler = loadStateHandler;
    } else if (state == RUN_STATE) {
      stateHandler = runStateHandler;
    } else if (state == END_STATE) {
      stateHandler = endStateHandler;
    }
  }
  else {
    stateHandler = newState;
  }



  stateHandler.start();

  if(typeof app != "undefined")
    app.changeSceneEvent(stateHandler);

  
}

var state;        //State variable that tracks my current scene    

//A set of states we can be in, where each state represents a scene
var TITLE_STATE = 1;  //The opening scene, which displays the title of our game
var LOAD_STATE = 2;   //The load scene, which shows a loading progreess bar
var RUN_STATE = 3;    //The main scene, where the game runs
var END_STATE = 4;    //An end state, which the user sees which the game ends

//Set our intital scene state to the title state
state = RUN_STATE;

var Time = {}                                     //Stores information about time that is available to our game
var msBetweenFrames = 1000 / 30;                //Time in milliseconds between frames
Time.deltaTime = msBetweenFrames / 1000;        //Time in seconds between frames.

//Setup the canvas variables
var canvas = document.getElementById("canv");
canvas.style.width = '100%';
canvas.style.height = '100%';
canvas.width = canvas.offsetWidth;
canvas.height = canvas.offsetHeight;

var width = canvas.width;
var height = canvas.height;


var ctx = canvas.getContext("2d");


var runStateHandler = new RunScene();
var titleStateHandler = new TitleScene();
var endStateHandler = new EndScene();
var loadStateHandler = new LoadScene();

allScenes = [
  titleStateHandler,
  loadStateHandler,
  runStateHandler,
  endStateHandler
];

function main() {


  if(typeof app != "undefined")
    app.loadScenes();
    
  updateStateHandler();                 //Load the current scene in our state machine


  setInterval(timer, msBetweenFrames);  //Start the main timer to be called 30 times a second (every 33.3ms)
}