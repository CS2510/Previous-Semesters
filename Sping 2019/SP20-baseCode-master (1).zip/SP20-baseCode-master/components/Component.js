class Component{
 get name(){
   return this.constructor.name;
 }
}