class GUIContainer extends GameObject{
  constructor(){
    super("GUI Container");
  }
  
}