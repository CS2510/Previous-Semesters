class RunScene extends Scene {
  constructor() {
    super("Run Scene");
  }
  start() {
    super.start();

    this.otherSquare = new Bad();
    this.otherSquare.transform.position.x = 3;
    this.otherSquare.transform.position.y = 4;


    this.square = new Good();

    this.camera = new Camera(40, "azure");
    this.camera.transform.position = new Vector2(1 / 2, 1 / 2);


    var rDimensions = positionGUI(width, height, .25, 20, .25)
    this.guiComponent = new GUIRectangleComponent(new AxisAlignedRectangle(rDimensions.width, rDimensions.height), "gray");
    this.guiContainer = new GUIContainer();
    this.guiContainer.components.push(this.guiComponent);
    this.guiContainer.rendererGUI = this.guiComponent;
    this.guiContainer.transform.position.x = rDimensions.x;
    this.guiContainer.transform.position.y = rDimensions.y;

    this.guiTextObject = new GUITextObject("Run Scene");
    this.guiTextObject.transform.position = new Vector2(width / 2, rDimensions.y + rDimensions.height / 2);



    this.hierarchy.push(this.square);
    this.hierarchy.push(this.otherSquare);
    this.hierarchy.push(this.camera);
    this.hierarchy.push(this.guiContainer);
    this.hierarchy.push(this.guiTextObject);
  }
  eventPump(event) {
    super.eventPump(event);
    switch (event.name) {
      case "click":
        //this.nextScene();
        break;
      case "resize":
        var rDimensions = positionGUI(width, height, .25, 20, .25)
        this.guiComponent = new GUIRectangleComponent(new AxisAlignedRectangle(rDimensions.width, rDimensions.height), "gray");
        this.guiContainer.components = [];
        this.guiContainer.components.push(this.guiComponent);
        this.guiContainer.rendererGUI = this.guiComponent;
        this.guiContainer.transform.position.x = rDimensions.x;
        this.guiContainer.transform.position.y = rDimensions.y;

        this.guiTextObject.transform.position = new Vector2(width / 2, rDimensions.y + rDimensions.height / 2);


        break;


    }
  }
  newSquare() {
    while (this.isInCollision()) {
      this.otherSquare.transform.position.x = (Math.random() * 2 - 1) * 6;
      this.otherSquare.transform.position.y = (Math.random() * 2 - 1) * 6;
    }
  }
  isInCollision() {
    var p1 = this.square.transform.position;
    var p2 = this.otherSquare.transform.position;

    /*var xDiff = Math.abs(p1.x - p2.x);
    var yDiff = Math.abs(p1.y - p2.y);
    var d = Math.max(xDiff, yDiff);
    if (d < 2)
      return true;
    return false*/

    let x = this.square.transform.position.x + -this.otherSquare.transform.position.x;
    let y = this.square.transform.position.y + -this.otherSquare.transform.position.y;


    let triangle = this.otherSquare.getComponent(GeometryComponent).Geometry;
    let line1 = new Line(triangle.points[0], triangle.points[1]);
    let line2 = new Line(triangle.points[1], triangle.points[2]);
    let line3 = new Line(triangle.points[2], triangle.points[0]);
    let result1 = line1.a * x + line1.b * y + line1.c;
    let result2 = line2.a * x + line2.b * y + line2.c;
    let result3 = line3.a * x + line3.b * y + line3.c;
    if (result1 > 0 && result2 > 0 && result3 > 0) return true;
    return false;
  }
  nextScene() {
    state = END_STATE;
    updateListeners.splice(updateListeners.indexOf(this), 1);
    updateStateHandler();
  }
  update() {
    //This is where I update my model. I don't do any rendering here.

    if (this.isInCollision()) {
      this.newSquare();
    }


  }

}