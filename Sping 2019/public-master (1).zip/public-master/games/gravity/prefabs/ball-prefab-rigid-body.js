export default {
  name: "BallPrefabRigidBody", components:[
    {name: "DrawGeometryComponent", args: ["white"] },
    {name: "CircleGeometryComponent", args:[1]},
    {name:"RigidBodyComponent"}
  ]
}