export default {
  name: "MainController", components: [
    { name: "MainControllerComponent", },
    { name: "ScoreComponent" },
    { name: "SceneChangerComponent" }
  ]
}