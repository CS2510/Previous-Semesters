export default class Time{
  
}