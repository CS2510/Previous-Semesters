export default class Polygon{
  constructor(){
    
  }
}