export default  class Component{
    constructor(gameObject){
        this.gameObject = gameObject;
        this.enabled = true;
    }
}