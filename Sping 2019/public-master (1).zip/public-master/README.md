# Game Engine from CS 2510, University of Nebrask at Omaha

To play the game, create a server and open ```index.html```

If you make changes to components, scenes, or prefabs,  go into the game directory and run ```node build.js``` to create new modules with the required exports.