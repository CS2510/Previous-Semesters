export default {
  name: "${name}", components:[
    
  ]
}