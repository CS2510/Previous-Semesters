const SceneManager = Engine.SceneManager;

export default class ${name} extends Engine.Component {
  constructor(gameObject) {
    super(gameObject);
  }
  start() {    
  }
  update() {
  }
}