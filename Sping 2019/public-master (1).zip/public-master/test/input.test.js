import chai from "chai";
const expect = chai.expect;
import Input from "../engine/input.js"

describe("Input", function(){

	describe("constructor", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("SwapArrays", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("getKey", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("getKeyDown", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("getKeyUp", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("getMouseButton", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("getMouseButtonDown", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("getMouseButtonUp", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("getScrollWheel", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("getMousePosition", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("getMousePositionDelta", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("attach", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("keys", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("keysDown", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("keysUp", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("frameKeysDown", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("frameKeysUp", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("mouseButtons", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("mouseButtonsDown", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("mouseButtonsUp", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("frameMouseButtonsDown", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("frameMouseButtonUp", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("mousePosition", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("frameMousePosition", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("lastFrameMousePosition", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("scrollWheel", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
	describe("frameScrollWheel", function(){
		it("Works properly", function(){
			//TODO: Add Test
		});
	});
});